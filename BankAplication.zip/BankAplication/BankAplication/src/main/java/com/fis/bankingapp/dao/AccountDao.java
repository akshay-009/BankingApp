package com.fis.bankingapp.dao;

import java.util.List;

import com.fis.bankingapp.model.Account;

public interface AccountDao {
	public String createAccount(Account account);
	public Account getAccount(long getAcc); 
	public List<Account> getAllAccounts();
	public String updateAccount(Account account);
	public String deleteAccount(long getacc);
	
	public String deposit(long getAcc, double depositAmount);
	public String withdraw(long getAcc, double withdrawAmount); 
	public String fundTransfer(long fromAcc, long toAcc, double amount);


}

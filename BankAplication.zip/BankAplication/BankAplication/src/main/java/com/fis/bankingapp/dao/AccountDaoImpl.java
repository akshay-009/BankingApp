package com.fis.bankingapp.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankingapp.model.Account;
import com.fis.bankingapp.model.Transaction;

@Repository
public class AccountDaoImpl implements AccountDao {
	Date today=new Date();

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public String createAccount(Account account) {
		// TODO Auto-generated method stub
		entityManager.persist(account);
		return "Account Created Successfully";
	}

	
	@Override
	public Account getAccount(long getAcc) {
		// TODO Auto-generated method stub
		return entityManager.find(Account.class, getAcc);
	}

	@Override
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		TypedQuery<Account> query = entityManager.createQuery("select a from Account a",Account.class);
		return query.getResultList();
	}

	@Override
	public String updateAccount(Account account) {
		// TODO Auto-generated method stub
		entityManager.merge(account);
		return "Account Updated Successfully";
		
	}

	@Override
	public String deleteAccount(long getacc) {
		// TODO Auto-generated method stub
		entityManager.remove(getAccount(getacc));
		return "Account Deleted Successfully";
		
	}

	@Override
	public String deposit(long getAcc, double depositAmount) {
		// TODO Auto-generated method stub
		Account account = getAccount(getAcc);
		Transaction transaction= new Transaction();
		transaction.setAmount(depositAmount);
		transaction.setFromaccount(getAcc);
		transaction.setTranstime(today);
		account.setBalance(account.getBalance()+depositAmount);
		transaction.setTranstype("Deposit");
		transaction.setStatus("SUCCESS");
		entityManager.merge(transaction);
		entityManager.persist(account);
		return "Amount deposited Successfully";
		
	}

	@Override
	public String withdraw(long getAcc, double withdrawAmount ) {
		// TODO Auto-generated method stub
		Account account = getAccount(getAcc);
		Transaction transaction= new Transaction();
		transaction.setAmount(withdrawAmount);
		transaction.setFromaccount(getAcc);
		transaction.setTranstime(today);
		transaction.setTranstype("Withdraw");
		if (account.getBalance() < withdrawAmount) {
           // throw new RuntimeException("Insufficient funds");
			transaction.setStatus("FAILED");
			return "Insufficient Funds";
        }
        account.setBalance(account.getBalance() - withdrawAmount);
        transaction.setStatus("SUCCESS");
        entityManager.merge(transaction);
        return "Amount withdrawl Successfully ";	
		
	}

	@Override
	public String fundTransfer(long fromAcc, long toAcc, double amount) {
		// TODO Auto-generated method stub
		   withdraw(fromAcc,amount);
		   deposit(toAcc,amount);
		   Transaction transaction= new Transaction();
			transaction.setAmount(amount);
			transaction.setFromaccount(fromAcc);
			transaction.setToaccount(toAcc);
			transaction.setTranstime(today);
			transaction.setTranstype("Fund Transfer");
			transaction.setStatus("SUCCESS");
			entityManager.merge(transaction);
		
		return "Fund Transfer Successfully";
	}


}

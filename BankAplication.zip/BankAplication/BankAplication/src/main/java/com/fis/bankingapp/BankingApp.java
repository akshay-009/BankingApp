package com.fis.bankingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingApp {

	public static void main(String[] args) {
		SpringApplication.run(BankingApp.class, args);
	}

}

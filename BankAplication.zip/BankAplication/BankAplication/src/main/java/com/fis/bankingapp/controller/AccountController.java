package com.fis.bankingapp.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankingapp.model.Account;
import com.fis.bankingapp.service.AccountService;

//{
//    "accopendate": "2023-11-02",
//    "accounttype": "Savings",
//    "balance": 0,
//    "branch": "Hyd"
//}
@RestController
@RequestMapping("/accounts")
public class AccountController {
	@Autowired
	AccountService service;
	
	@PostMapping("/createAccount")
	public String createAccount(@RequestBody Account account) {
		return service.createAccount(account);
	}
	
	@GetMapping("/getAccount/{acc}")
	public Account getAccount(@PathVariable("acc") long getAcc) {
		return service.getAccount(getAcc);
	}
	
	@GetMapping("/getAllAccounts")
	public List<Account> getAllAccounts(){
		return service.getAllAccounts();
		
	}
	
	@PutMapping("/updateAccount")
	public String updateAccount(@RequestBody Account account) {
		return service.updateAccount(account);
	}
	
	@DeleteMapping("/deleteAccount/{acc}")
	public String deleteAccount(@PathVariable("acc") long getacc) {
		return service.deleteAccount(getacc);
	}
	
	@PostMapping("/deposit/{acc}")
	public String deposit(@PathVariable("acc") long getAcc, @RequestBody Map<String, Double> request ) {
		Double depositAmount = request.get("depositAmount");
		return service.deposit(getAcc, depositAmount);
		
	}
	
	@PostMapping("/withdraw/{acc}")
	public String withdraw(@PathVariable("acc") long getAcc, @RequestBody Map<String, Double> request ) {
		Double withdrawAmount = request.get("withdrawAmount");
		return service.withdraw(getAcc, withdrawAmount);
		
	}
	
	@PostMapping("fundTransfer/{fromAcc}/{toAcc}")
	public String fundTransfer(@PathVariable long fromAcc, @PathVariable long toAcc,@RequestBody Map<String, Double> request) {
		Double amount = request.get("amount");
		return service.fundTransfer(fromAcc, toAcc, amount);
	}


}
